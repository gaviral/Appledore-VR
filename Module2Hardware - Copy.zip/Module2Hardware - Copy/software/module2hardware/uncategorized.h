#include "graphics.h"
#include <stdbool.h>

//#define ROADMAP 0
//#define SATELLITE 1
//#define TERRAIN 2
//#define HYBRID 3

#define Tx_Mask 0x02
#define Rx_Mask 0x01

#define PRESSED_BUTTON_COLOR CYAN
#define UNpressed_BUTTON_COLOR WHITE

#define ROUTE_1 1
#define ROUTE_2 2

#define NUM_OF_MARKERS 2

extern const unsigned int ColourPalletteData[256];
extern const unsigned int mapColourPalletteData[256];

#define DEFAULT_PALLETTE 0
#define MAP_PALLETTE 1

typedef struct {
	double start_x;
	double start_y;
	char file_name[10];
	int current_map_number;
	//todo: add user_contact for emergency
} Demo_Map;


typedef struct {
	int hh;
	int mm;
	int ss;
} time_struct;





typedef struct {
	double latitude;
	double longitude;
	time_struct time;
} GPS_data_struct;


typedef struct {
	double latitude;
	double longitude;
}coordinates;

typedef struct{
	coordinates start_location;
	coordinates end_location;
	time_struct start_time;
	time_struct end_time;
	bool trip_started;
	double distance_travelled;
	time_struct time_elapsed;
	int calories_burnt;
} Trip_report;
