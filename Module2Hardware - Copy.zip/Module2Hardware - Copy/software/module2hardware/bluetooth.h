#define Bluetooth_Control (*(volatile unsigned char *)(0x84000220))
#define Bluetooth_Status (*(volatile unsigned char *)(0x84000220))
#define Bluetooth_TxData (*(volatile unsigned char *)(0x84000222))
#define Bluetooth_RxData (*(volatile unsigned char *)(0x84000222))
#define Bluetooth_Baud (*(volatile unsigned char *)(0x84000224))

// string definitions for command translations
#define FORWARD ((const char) 'F')
#define LEFT ((const char) 'L')
#define RIGHT ((const char) 'R')
#define MAX_CMD_SIZE 50

void delay(unsigned int mseconds);
void init_bluetooth(void);
void bt_send_command(char *cmd);
void translate_command(int input, char *command);
void bluetooth_send_command(int pushbutton);
void updatePushbuttons(void);
