#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include "touchscreen.h"
#include "uncategorized.h"
#include "Colours.h"
#include "bmp.h"
#include "GPS.h"
#include "map.h"
#include <math.h>
#include "screen.h"
#include "bluetooth.h"
#include "key_codes.h"

/*
 * To create a screen add it bellow
 * 	+ it's calling code in render_screen() below
 */
//***********************  WELCOME SCREEN  ***************************

int current_screen_num = 1;
GPS_data_struct cur_GPS;
GPS_data_struct previous_GPS;
Trip_report current_trip;

#define DOFILE_TEXT "dofile('send_text_message.lua')\r\n"
// carriage return and new line
#define CR_NL ((const char *) "\r\n")

int pushbutton_pressed = NOKEY;
int last_pushbutton = NOKEY;

volatile int * slider_switch_ptr = (int *) SWITCHES_BASE_ADDR;
volatile int * red_leds_ptr = (int *) LEDS_BASE_ADDR;

int count = 0;
void testingWifi() {

	printf("sending text \n");
	char str[150];
	sprintf(str, "send_sms(\"(604) 330-1334\",\"(604) 440-1509\",\"!!!HAZARD ALERT!!! Use caution around your current location.\", \"%f\", \"%f\")\r\n", cur_GPS.latitude, cur_GPS.longitude);
	printf(str);
	delayWifi(1);
	Init_Wifi();
	delayWifi(1);
	delayWifi(1);
	delayWifi(1);
	putstringWifi(DOFILE_TEXT);
	delayWifi(1);
	putstringWifi(str);
}

int main() {
	//change_pallette(DEFAULT_PALLETTE);
	//gen_palette();
	Init_Touch();
	Init_GPS();
	controller_init();
	init_bluetooth();

	while(1) {
		if(ScreenTouched()) {
			if (TouchScreen_RxData == 0x80) {
				GetRelease();
			} else if (TouchScreen_RxData == 0x81) {
				GetPress();
			}
		}
		get_gps_data();
		if(check_significant_GPS_change_for_real()){
			//send through wifi
			printf("3: %lf %lf\n", cur_GPS.latitude, cur_GPS.longitude);
		}

		*(red_leds_ptr) = *(slider_switch_ptr);
		updatePushbuttons();
		if (pushbutton_pressed != NOKEY) {
			if (last_pushbutton != pushbutton_pressed) {
				bluetooth_send_command(pushbutton_pressed);
			}
		}

		if (count == 0) {
			testingWifi();
			count = 1;
		}
	}
}
