#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include "uncategorized.h"
#include "bluetooth.h"
#include "key_codes.h"

void init_bluetooth(void) {
	// Program 6850 and baud rate generator to communicate with Bluetooth
	Bluetooth_Control = 0x15;
	Bluetooth_Baud = 0x01;
}

/* Function to send a command via Bluetooth to a connected device */
void bt_send_command(char *cmd) {
	int i = 0;
	while (cmd[i] != '\0') {
		if ((Bluetooth_Status & Tx_Mask)) {
			Bluetooth_TxData = cmd[i];
			//delay(5);
			i++;
		}
	}
}

// function to translate inputs into navigation commands
void translate_command(int input, char *command) {
	char cmd = 0;
	switch (input) {
		case KEY1:
			cmd = FORWARD;
			break;
		case KEY2:
			cmd = RIGHT;
			break;
		case KEY3:
			cmd = LEFT;
			break;
		default:
			break;
	}

	command[0] = cmd;

	// add the carriage return and new line
	// APPARENTLY, this is not required
	//strcat(command, CR_NL);

	printf("%s ", command);
}

void bluetooth_send_command(int pushbutton) {

	char command[MAX_CMD_SIZE];
	if (pushbutton != NOKEY) {
		//printf("%d\n", pushbutton_pressed);
		// translate the pushbutton into navigation command
		translate_command(pushbutton, command);
		// send this translated command to Android via BT
		bt_send_command(command);
		// clear the string after sending it
		memset(&command[0], 0, MAX_CMD_SIZE);
	}
}

extern int pushbutton_pressed;
extern int last_pushbutton;
volatile int * KEY_ptr = (int *) PUSHBUTTONS_BASE_ADDR;

void updatePushbuttons() {
	int press;
	press = *KEY_ptr;
	char key_char = 'x';

	if (press == KEY1_V) {
		last_pushbutton = pushbutton_pressed;
		pushbutton_pressed = KEY1;
		key_char = '1';
	} else if (press == KEY2_V) {
		last_pushbutton = pushbutton_pressed;
		pushbutton_pressed = KEY2;
		key_char = '2';
	} else if (press == KEY3_V) {
		last_pushbutton = pushbutton_pressed;
		pushbutton_pressed = KEY3;
		key_char = '3';
	} else if (press == NOKEY_V || press == 0) {
		last_pushbutton = pushbutton_pressed;
		pushbutton_pressed = NOKEY;
		key_char = 'x';
	}
}

