/*
 * GPS.h
 *
 *  Created on: 2017-01-31
 *      Author: David Wong
 */

#ifndef GPS_H_
#define GPS_H_

#define GPS_Status 		(*(volatile unsigned char *)(0x84000210))
#define GPS_Control 	(*(volatile unsigned char *)(0x84000210))
#define GPS_TxData 		(*(volatile unsigned char *)(0x84000212))
#define GPS_RxData 		(*(volatile unsigned char *)(0x84000212))
#define GPS_Baud    	(*(volatile unsigned char *)(0x84000214))

typedef struct GPS_Data{
	char ID[6];
	char time[11];
	double latitude;
	double longitude;
	char NS[2];
	char EW[2];
	char position[2];
	int numSat;
	char HDOP[5];
	double alt;
	char altUnit[2];
	double geo;
	char geoUnit[2];
} GPS_data;

void Init_GPS(void);
void putcharGPS(int c);
char getcharGPS(void);
void GPSReadLine(char buffer[]);
void GPSReceivedData(void);
int checkLine(char buffer[]);
void GPSParseLine(char line[], GPS_data *currentData);
void rawData(GPS_data rawData);
int GPSTransmitData(void);
void print_gps_data(GPS_data* data);
void getTime(int current[]);
void newGPS(GPS_data *global, int current[]);
void get_gps_data(void);
int check_significant_GPS_change_for_real(void);

#endif /* GPS_H_ */
