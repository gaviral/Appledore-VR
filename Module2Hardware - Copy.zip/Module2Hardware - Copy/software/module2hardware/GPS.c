/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "GPS.h"
#include "uncategorized.h"

//Initialise GPS Connection to the NIOS
void Init_GPS(void)
{
	GPS_Baud = 0x05;
	GPS_Control = 0x15;

}
//Write a char into the GPS
void putcharGPS(int c)
{
	while (!(GPS_Status & 0x2));
    GPS_TxData = c;
}
//Read a char from the GPS
char getcharGPS( void )
{
	while (!(GPS_Status & 0x1));
	return GPS_RxData;
}

//This function reads one line at a time
void GPSReadLine(char buffer[]){

	int count = 0;
	char gpsChar = '\0';
	while(gpsChar != '$') {
		gpsChar = getcharGPS();
		//printf("%c",gpsChar);
	}
	while(gpsChar != '\n') {
		gpsChar = getcharGPS();
		//printf("%c",gpsChar);
		buffer[count] = gpsChar;
		count++;
	}
	buffer[count] = '\0';

}


//Reading Data from GPS
void GPSReceivedData(void)
{
	Init_GPS();
	char charBuffer[100];
	GPS_data myData;
	GPSReadLine(charBuffer);
	while(checkLine(charBuffer) == 0){
	 GPSReadLine(charBuffer);
	}
	 rawData(myData);
	 GPSParseLine(charBuffer, &myData);

}


void newGPS(GPS_data *global, int current[]){
	//REAL

	Init_GPS();
		char charBuffer[100];
		GPSReadLine(charBuffer);
		while(checkLine(charBuffer) == 0){
		 GPSReadLine(charBuffer);
		}
		 GPSParseLine(charBuffer, global);
		     char h0 = global->time[0];
		     int h0i = atoi(&h0);
		     char h1 = global->time[1];
		     int h1i = atoi(&h1);
		     int hour = h0i * 10 + h1i;

		    //Get minute
		     char m0 = global->time[2];
		     int m0i = atoi(&m0);
		     char m1 = global->time[3];
		     int m1i = atoi(&m1);
		     int minute = m0i * 10 + m1i;

		     //Get second
		     char s0 = global->time[4];
		     int s0i = atoi(&s0);
		     char s1 = global->time[5];
		     int s1i = atoi(&s1);
		     int second = s0i * 10 + s1i;

		     current[0] = hour-8+24;
		     current[1] = minute;
		     current[2] = second;


}

//This function checks if the line is what we want (GPGGA)
int checkLine(char buffer[]){

	int result = 0;
	if(buffer[3]== 'G' && buffer[2]== 'G')
	result = 1;
	return result;
}

//This function parse the char line data into GPS data
void GPSParseLine(char line[], GPS_data *currentData){


	const char s[12] = ",";
	char  tempBuffer[16][12];
	int   num = 0;
	char *token;
	   /* get the first token */
	   token = strtok(line, s);
	 //  printf( " First Token: %s\n", token );
	   /* walk through other tokens */
	   while( token != NULL )
	   {
		  strcpy(tempBuffer[num], token);
	     // printf( " %s\n", token );
	      token = strtok(NULL, s);
	      num++;
	   }

	   strncpy(currentData->ID, tempBuffer[0], 6);
	   strncpy(currentData->time, tempBuffer[1], 11);

	   // TODO CORRECT LONG/LAT BASED ON CARDINAL DIRECTION
	   double floatLat = atof(tempBuffer[2]);
	   floatLat /= 100;
	   int intPartLat = (int) floatLat;
	   double decPartLat = (floatLat - intPartLat)*100/60;
	   floatLat = intPartLat + decPartLat;

	   double floatLong = atof(tempBuffer[4]);
	   floatLong /= 100;
	   int intPartLong = (int) floatLong;
	   double decPartLong = (floatLong - intPartLong)*100/60;
	   floatLong = intPartLong + decPartLong;

	   currentData->latitude = floatLat;
	   currentData->longitude = floatLong;
	   strncpy(currentData->NS, tempBuffer[3], 2);
	   strncpy(currentData->EW, tempBuffer[5], 2);
	   strncpy(currentData->position,tempBuffer[6], 2);
	   currentData->numSat = atoi(tempBuffer[7]);
	   strncpy(currentData->HDOP, tempBuffer[8], 5);
	   currentData->alt = atof(tempBuffer[9]);
	   strncpy(currentData->altUnit, tempBuffer[10], 2);
	   currentData->geo = atof(tempBuffer[11]);
	   strncpy(currentData->geoUnit, tempBuffer[12], 2);

	   if(currentData->EW[0] == 'W')
		currentData->longitude = -1*(currentData->longitude);
	   if(currentData->NS[0] == 'S')
	   	currentData->latitude = -1*(currentData->latitude);


}
void rawData(GPS_data rawData){


	rawData.ID[6] = "GPGGA";
	rawData.time[11] = '0';
	rawData.latitude = 0;
	rawData.longitude = 0;
	rawData.NS[2] = '0';
	rawData.EW[2] = '0';
	rawData.position[2] = '0';
	rawData.numSat = 0;
	rawData.HDOP[5] = '0';
	rawData.alt = 0;
	rawData.altUnit[2] = '0';
	rawData.geo = 0;
	rawData.geoUnit[2] = '0';

}

void getTime(int current[])
{
	char charBuffer[100];
	GPS_data myData;
	GPSReadLine(charBuffer);
	while(checkLine(charBuffer) == 0){
	 GPSReadLine(charBuffer);
	}
	 GPSParseLine(charBuffer, &myData);
	 //Get hour
     char h0 = myData.time[0];
     int h0i = atoi(&h0);
     char h1 = myData.time[1];
     int h1i = atoi(&h1);
     int hour = h0i * 10 + h1i;

    //Get minute
     char m0 = myData.time[2];
     int m0i = atoi(&m0);
     char m1 = myData.time[3];
     int m1i = atoi(&m1);
     int minute = m0i * 10 + m1i;

     //Get second
     char s0 = myData.time[4];
     int s0i = atoi(&s0);
     char s1 = myData.time[5];
     int s1i = atoi(&s1);
     int second = s0i * 10 + s1i;

     current[0] = hour+24;
     current[1] = minute;
     current[2] = second;

}



int GPSTransmitData(void) {
	return 0;
}

void print_gps_data(GPS_data* data){

}

extern GPS_data_struct cur_GPS;
extern GPS_data_struct previous_GPS;

void get_gps_data(){
	previous_GPS.latitude = cur_GPS.latitude;
	previous_GPS.longitude = cur_GPS.longitude ;
	previous_GPS.time.hh = cur_GPS.time.hh;
	previous_GPS.time.mm = cur_GPS.time.mm;
	previous_GPS.time.ss = cur_GPS.time.ss;

	GPS_data gpsData;
	int gpsTime[3];
	newGPS(&gpsData, gpsTime);
	cur_GPS.latitude = gpsData.latitude;
	cur_GPS.longitude = gpsData.longitude;
	cur_GPS.time.hh = gpsTime[0];
	cur_GPS.time.mm = gpsTime[1];
	cur_GPS.time.ss = gpsTime[0];
    printf("Lat: %.4f\n",cur_GPS.latitude);
    printf("Long: %.4f\n",cur_GPS.longitude);
    printf("Hour: %d\n", cur_GPS.time.hh);
    printf("Minute: %d\n", cur_GPS.time.mm);
    printf("Second: %d\n", cur_GPS.time.ss);
}

int check_significant_GPS_change_for_real(){

	double lat_change = previous_GPS.latitude-cur_GPS.latitude;
	double long_change = previous_GPS.longitude-cur_GPS.longitude;

	if (lat_change < 0) {
		lat_change = -lat_change;
	}
	if (lat_change > 0.0200) {
		return 1;
	}

	if (long_change < 0) {
		long_change = -long_change;
	}
	if (long_change > 0.1000) {
		return 1;
	}
	return 0;
}

